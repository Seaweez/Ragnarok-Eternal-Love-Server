#include <stdio.h>

int main()
{
	puts(""#MSG);
	return 0;
}
