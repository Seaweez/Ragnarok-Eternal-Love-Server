using System;

public class CsSharedLib
{
	public void DoIt()
	{
		Console.WriteLine("CsSharedLib");
	}
}
