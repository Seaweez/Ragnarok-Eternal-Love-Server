#include <stdio.h>

void CppSharedLib()
{
	printf("CppSharedLib\n");
}
